<?php
?>
<h1>Combinar PDF's</h1>
<p>
Ejemplo demostrativo de combinación de documentos PDF. 
<a href="https://parzibyte.me/blog/2019/02/04/unir-combinar-archivos-pdf-php-libmergepdf/">Mira el tutorial</a>
<br>

<br>
Ahora puedes visitar lo siguiente:
<br>
<a href="./mostrar_en_navegador.php">Mostrar PDF combinado en navegador</a>
<br>
<a href="./descargar.php">Forzar descarga de PDF</a>
<br>
<a href="./guardar.php">Guardar en disco duro</a> (mira la <a href="./combinado.pdf">salida</a> después de haberlo guardado)
<br><br>
Por cierto, aquí los documentos utilizados:

<br>
<a href="./parzibyte.pdf">parzibyte.pdf</a>
<br>
<a href="./cotizacion.pdf">cotizacion.pdf</a>
<br>
<a href="./documento.pdf">documento.pdf</a>
<br>
by <a href="https://parzibyte.me">parzibyte</a>
</p>